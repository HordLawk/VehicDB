#include <stdio.h>

char *readWord(FILE *stream, char separador);
void binarioNaTela(char *nomeArquivoBinario);
void linebreak(FILE *stream);
void scan_quote_string(char *str);